package com.respo.respo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RespoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RespoApplication.class, args);
		System.out.println("Ok");
	}

}
