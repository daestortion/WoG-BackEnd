package com.respo.respo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.respo.respo.Entity.CarEntity;
import com.respo.respo.Service.CarService;

@RestController
@RequestMapping("/car")
@CrossOrigin(origins = ("http://localhost:3000"))
public class CarController {

	@Autowired
	CarService cserv;

	@GetMapping("/print")
	public String itWorks() {
		return "It works";
	}

	// Create
	@PostMapping("/insertCar")
	public CarEntity insertCar(@RequestBody CarEntity car) {
		return cserv.insertCar(car);
	}

	// Read
	@GetMapping("/getAllCars")
	public List<CarEntity> getAllCars() {
		return cserv.getAllCars();
	}

	// U - Update a user record
	@PutMapping("/updateCar")
	public CarEntity updateCar(@RequestParam int carId, @RequestBody CarEntity newCarDetails) {
		return cserv.updateCar(carId, newCarDetails);
	}

	// D - Delete a user record
	@DeleteMapping("/deleteCar/{CarId}")
	public String deleteCar(@PathVariable int carId) {
		return cserv.deleteCar(carId);
	}

}
