package com.respo.respo.Service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.respo.respo.Entity.CarEntity;
import com.respo.respo.Repository.CarRepository;

@Service
public class CarService {

	@Autowired
	CarRepository crepo;
	
	// Create 
	public CarEntity insertCar(CarEntity car) {
		return crepo.save(car);
	}
	
	// Read 
	public List<CarEntity> getAllCars() {
		return crepo.findAll();
	}

	// Update
	@SuppressWarnings("finally")
	public CarEntity updateCar(int carId, CarEntity newCarDetails) {
	    CarEntity car = crepo.findById(carId)
	        .orElseThrow(() -> new NoSuchElementException("Car " + carId + " does not exist!"));

	    // Check and update carName if it's not null or empty
	    if (newCarDetails.getCarName() != null && !newCarDetails.getCarName().isEmpty()) {
	        car.setCarName(newCarDetails.getCarName());
	    }

	    // Check and update plateNum if it's not null or empty
	    if (newCarDetails.getPlateNum() != null && !newCarDetails.getPlateNum().isEmpty()) {
	        car.setPlateNum(newCarDetails.getPlateNum());
	    }

	    // Check and update eMail if it's not null or empty
	    if (newCarDetails.geteMail() != null && !newCarDetails.geteMail().isEmpty()) {
	        car.seteMail(newCarDetails.geteMail());
	    }

	    // Check and update pNum if it's not null or empty
	    if (newCarDetails.getpNum() != null && !newCarDetails.getpNum().isEmpty()) {
	        car.setpNum(newCarDetails.getpNum());
	    }

	    // There is no need for a try-catch block here as findById with orElseThrow already handles the exception
	    return crepo.save(car);
	}

	
	// Delete
	public String deleteCar(int carId) {
		CarEntity car = crepo.findById(carId)
			.orElseThrow(() -> new NoSuchElementException("Car " + carId + "does not exist"));

		if (car.isDeleted()) {
			return "Car #" + carId + " is already deleted!";
		} else {
			car.setDeleted(true);
			crepo.save(car);
			return "Car #" + carId + "has been deleted";
		}
	}
}
