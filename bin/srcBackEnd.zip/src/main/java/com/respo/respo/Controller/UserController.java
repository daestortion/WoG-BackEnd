package com.respo.respo.Controller;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.respo.respo.Entity.UserEntity;
import com.respo.respo.Service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = ("http://localhost:3000"))
public class UserController {

	@Autowired
	UserService userv;

	@GetMapping("/print")
	public String itWorks() {
		return "It works";
	}

	// Create
	@PostMapping("/insertUser")
	public UserEntity insertUser(@RequestBody UserEntity user) {
		return userv.insertUser(user);
	}

	// Read
	@GetMapping("/getAllUsers")
	public List<UserEntity> getAllUsers() {
		return userv.getAllUsers();
	}

	// U - Update a user record
	@PutMapping("/updateUser")
	public UserEntity updateUser(@RequestParam int userId, @RequestBody UserEntity newUserDetails) {
		return userv.updateUser(userId, newUserDetails);
	}

	// D - Delete a user record
	@DeleteMapping("/deleteUser/{userId}")
	public String deleteUser(@PathVariable int userId) {
		return userv.deleteUser(userId);
	}

	@PostMapping("/login")
	public int loginUser(@RequestBody Map<String, String> credentials) {
		String identifier = credentials.get("identifier");  // Changed from email to identifier
		String password = credentials.get("password");

		return userv.loginUser(identifier, password);  // Pass identifier which can be either username or email
	}


    @GetMapping("/forgot-password")
	public ResponseEntity<?> forgotPassword(@RequestParam String identifier) {
		try {
			UserEntity user = userv.getUserByIdentifier(identifier);
			if (user != null) {
				// Assume you generate a reset token and store it with an expiry time in your database
				String resetLink = "http://yourfrontenddomain/reset-password?token=generatedToken";
				userv.sendPasswordResetEmail(user, resetLink);
				return ResponseEntity.ok("If the email is associated with an account, a reset link has been sent.");
			} else {
				return ResponseEntity.badRequest().body("No account associated with this email.");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while processing your request: " + e.getMessage());
		}
	}


    
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestParam int userId, @RequestParam String newPassword) {
        try {
            UserEntity user = userv.resetPassword(userId, newPassword);
            return ResponseEntity.ok("Password for user " + user.getUsername() + " has been successfully updated.");
        } catch (NoSuchElementException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

	@GetMapping("/currentUser")
	public ResponseEntity<UserEntity> getCurrentUser(HttpServletRequest request) {
    	System.out.println("Received request for current user");
    try {
        String username = request.getUserPrincipal().getName();  // Get username from the session or token
        UserEntity user = userv.getUserByUsername(username);
        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }
}

}
