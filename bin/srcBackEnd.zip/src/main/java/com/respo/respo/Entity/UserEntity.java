package com.respo.respo.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToMany;
import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import java.util.List;

@Entity
@Table(name = "tblUsers")
public class UserEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	
	@Column(name = "username")
	private String username; 
	
	@Column(name = "fName")
	private String fName;
	
	@Column(name = "isRenting")
	private boolean isRenting;
	
	@Column(name = "cars")
	@OneToMany(mappedBy = "owner", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<CarEntity> cars; // List to store cars associated with the user
	
	@Column(name = "lName")
	private String lName;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "pWord")
	private String pWord;

	@Column(name = "pNum")
	private String pNum;

	@Column(name = "is_admin")
    private boolean isAdmin;

	@Column(name = "is_deleted")
	private boolean isDeleted = false;
	
	public UserEntity() {}
	
	public UserEntity(int userId, String username, String fName, List<CarEntity> cars, String lName,
			String email, String pWord, String pNum) {
		super();
		this.userId = userId;
		this.username = username;
		this.fName = fName;
		this.isRenting = false;
		this.cars = cars;
		this.lName = lName;
		this.email = email;
		this.pWord = pWord;
		this.pNum = pNum;
		this.isAdmin = false;
		this.isDeleted = false;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public boolean isRenting() {
		return isRenting;
	}

	public void setRenting(boolean isRenting) {
		this.isRenting = isRenting;
	}

	public List<CarEntity> getCars() {
		return cars;
	}

	public void setCars(List<CarEntity> cars) {
		this.cars = cars;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getpWord() {
		return pWord;
	}

	public void setpWord(String pWord) {
		this.pWord = pWord;
	}

	public String getpNum() {
		return pNum;
	}

	public void setpNum(String pNum) {
		this.pNum = pNum;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	
	
	
}
