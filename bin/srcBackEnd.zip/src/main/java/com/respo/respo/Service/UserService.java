    package com.respo.respo.Service;

    import java.util.List;
    import java.util.NoSuchElementException;
    import java.util.Optional;

    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.mail.SimpleMailMessage;
    import org.springframework.mail.javamail.JavaMailSender;
    import org.springframework.stereotype.Service;
    import org.springframework.util.StringUtils;

    import com.respo.respo.Entity.UserEntity;
    import com.respo.respo.Repository.UserRepository;

    @Service
    public class UserService {

        @Autowired
        UserRepository urepo;

        @Autowired
        private JavaMailSender mailSender;

        // Create
        // UserService.java
        public UserEntity insertUser(UserEntity user) throws IllegalArgumentException {
            // Check if username or email already exists
            if (urepo.existsByUsername(user.getUsername())) {
                throw new IllegalArgumentException("Username already exists.");
            }
            if (urepo.findByEmail(user.getEmail()).isPresent()) {
                throw new IllegalArgumentException("Email already registered.");
            }
            return urepo.save(user);  // Save the user if checks pass
        }


        // Read
        public List<UserEntity> getAllUsers() {
            return urepo.findAll();
        }

        // Update
        public UserEntity updateUser(int userId, UserEntity newUserDetails) {
            UserEntity user = urepo.findById(userId).orElseThrow(() ->
                new NoSuchElementException("User " + userId + " does not exist!"));

            // Check for non-null and non-empty username
            if (newUserDetails.getUsername() != null && !newUserDetails.getUsername().isEmpty()) {
                // Ensure the new username is unique and not the current user's username
                if (!newUserDetails.getUsername().equals(user.getUsername()) && 
                    urepo.existsByUsername(newUserDetails.getUsername())) {
                    throw new IllegalStateException("Username already exists. Please choose a different username.");
                }
                user.setUsername(newUserDetails.getUsername());
            }
            
            if (newUserDetails.getfName() != null && !newUserDetails.getfName().isEmpty()) {
                user.setfName(newUserDetails.getfName());
            }
            if (newUserDetails.getlName() != null && !newUserDetails.getlName().isEmpty()) {
                user.setlName(newUserDetails.getlName());
            }
            if (newUserDetails.getEmail() != null && !newUserDetails.getEmail().isEmpty()) {
                user.setEmail(newUserDetails.getEmail());
            }
            if (newUserDetails.getpWord() != null && !newUserDetails.getpWord().isEmpty()) {
                user.setpWord(newUserDetails.getpWord());
            }
            if (newUserDetails.getpNum() != null && !newUserDetails.getpNum().isEmpty()) {
                user.setpNum(newUserDetails.getpNum());
            }
            
            return urepo.save(user);
        }

        // Delete
        public String deleteUser(int userId) {
            UserEntity user = urepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User " + userId + " does not exist"));

            if (user.isDeleted()) {
                return "User #" + userId + " is already deleted!";
            } else {
                user.setDeleted(true);
                urepo.save(user);
                return "User #" + userId + " has been deleted";
            }
        }

        public int loginUser(String identifier, String password) {
            Optional<UserEntity> userOpt = identifier.contains("@") ? 
                urepo.findByEmail(identifier) : urepo.findByUsername(identifier);
        
            if (userOpt.isPresent() && userOpt.get().getpWord().equals(password)) {
                return 1; // Login successful
            }
            return 0; // Login unsuccessful, either identifier not found or password incorrect
        }
        
        
        public UserEntity getUserByIdentifier(String identifier) {
            if (StringUtils.hasText(identifier)) {
                if (identifier.contains("@")) {
                    return urepo.findByEmail(identifier)
                                .orElseThrow(() -> new IllegalArgumentException("No user found with email: " + identifier));
                } else {
                    return urepo.findByUsername(identifier)
                                .orElseThrow(() -> new IllegalArgumentException("No user found with username: " + identifier));
                }
            }
            throw new IllegalArgumentException("Identifier is not provided or empty.");
        }
        
        public UserEntity resetPassword(int userId, String newPassword) {
            UserEntity user = urepo.findById(userId).orElseThrow(() ->
                new NoSuchElementException("No user found with ID: " + userId));
            
            user.setpWord(newPassword);  // Update the password
            urepo.save(user);
            return user;
        }

        public void sendPasswordResetEmail(UserEntity user, String resetLink) {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("ayadekenneth07@gmail.com");
            message.setTo(user.getEmail());
            message.setSubject("Password Reset Request");
            message.setText("To reset your password, click the following link: " + resetLink);
            try {
                mailSender.send(message);
                System.out.println("Email sent successfully to " + user.getEmail());
            } catch (Exception e) {
                System.out.println("Failed to send email to " + user.getEmail());
                e.printStackTrace();
            }
        }
        
        public UserEntity getUserByUsername(String username) {
            return urepo.findByUsername(username)
                        .orElseThrow(() -> new NoSuchElementException("User not found with username: " + username));
        }
        
    }
