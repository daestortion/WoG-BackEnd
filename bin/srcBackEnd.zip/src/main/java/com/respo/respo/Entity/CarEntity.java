package com.respo.respo.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;

@Entity
@Table(name = "tblCars")
public class CarEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int carId;

    @Column(name = "carName")
    private String carName;

    @ManyToOne
    @JoinColumn(name = "ownerId") // This column in the car table will hold the foreign key
    private UserEntity owner;

    public UserEntity getOwner() {
        return this.owner;
    }

    public void setOwner(UserEntity owner) {
        this.owner = owner;
    }

    @Column(name = "plateNum")
    private String plateNum;

    @Column(name = "carDesc")
    private String carDesc;

    @Column(name = "eMail")
    private String eMail;

    @Column(name = "pNum")
    private String pNum;

    @Column(name = "is_deleted")
    private boolean isDeleted = false;

    public CarEntity() {}

    public CarEntity(int carId, String carName, String plateNum, String carDesc, String eMail, String pNum, boolean isDeleted, UserEntity owner) {
        this.carId = carId;
        this.carName = carName;
        this.plateNum = plateNum;
        this.carDesc = carDesc;
        this.eMail = eMail;
        this.pNum = pNum;
        this.isDeleted = isDeleted;
        this.owner = owner;
    }

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getPlateNum() {
		return plateNum;
	}

	public void setPlateNum(String plateNum) {
		this.plateNum = plateNum;
	}

	public String getCarDesc() {
		return carDesc;
	}

	public void setCarDesc(String carDesc) {
		this.carDesc = carDesc;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getpNum() {
		return pNum;
	}

	public void setpNum(String pNum) {
		this.pNum = pNum;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

    
}
